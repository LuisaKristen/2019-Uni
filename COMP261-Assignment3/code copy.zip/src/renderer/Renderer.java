package renderer;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Renderer extends GUI {

    private Vector3D lightSource;
    private Scene scene;

    private ArrayList<Color> randomLightColours = new ArrayList<>();
    private ArrayList<Vector3D> randomLightVectors = new ArrayList<>();

    private float xRotate = 0f;
    private float yRotate = 0f;

    @Override
    protected void onLoad(File file) {
        List<Scene.Polygon> polys = new ArrayList<>();

        try {
            BufferedReader buffferReader = new BufferedReader(new FileReader(file));

            String line = buffferReader.readLine(); // total number of polygons, not needed

            String[] data;

            while ((line = buffferReader.readLine()) != null) { // each line represents a polygon
                data = line.split(",");

                if (data.length == 3) {// last line of document, the light source
                    float lightX = Float.parseFloat(data[0]);
                    float lightY = Float.parseFloat(data[1]);
                    float lightZ = Float.parseFloat(data[2]);
                    lightSource = new Vector3D(lightX, lightY, lightZ);
                } else { // every other line is a polygon

                    int[] lightVector = new int[3];
                    float[] polyVertices = new float[9];

                    //store the light vector
                    lightVector[0] = Integer.parseInt(data[0]);
                    lightVector[1] = Integer.parseInt(data[1]);
                    lightVector[2] = Integer.parseInt(data[2]);

                    // for storing the polygon vertices.
                    for (int j = 3; j < data.length; j++) {
                        polyVertices[j - 3] = Float.parseFloat(data[j]); //j-3 since the first three have already been done
                    }
                    // add this polygon to the list
                    polys.add(new Scene.Polygon(polyVertices, lightVector));
                }
            }
            // make a new scene with all the polygons and the light source
            scene = new Scene(polys, lightSource);
            buffferReader.close();

        } catch (Exception e) {
            System.out.println("Error: " + e);
        }

        /*
         * This method should parse the given file into a Scene object, which
         * you store and use to render an image.
         */
    }

    @Override
    protected void onKeyPress(KeyEvent ev) {
        // set the roatation amount based on the key that is pressed, the rotation itself is done in the render method

        if (ev.getKeyCode() == 37 || ev.getKeyCode() == 65) {
            yRotate = -0.1f;
            xRotate = 0f;
        }
        if (ev.getKeyCode() == 38 || ev.getKeyCode() == 87) {
            xRotate = -0.1f;
            yRotate = 0f;
        }
        if (ev.getKeyCode() == 39 || ev.getKeyCode() == 68) {
            yRotate = 0.1f;
            xRotate = 0f;

        }
        if (ev.getKeyCode() == 40 || ev.getKeyCode() == 83) {
            xRotate = 0.1f;
            yRotate = 0f;

        }
        /*
         * This method should be used to rotate the user's viewpoint.
         */
    }

    @Override
    protected BufferedImage render() {
        if (scene == null) // no image to render
            return null;

        //rotate, scale and translate the scene
        scene = Pipeline.rotateScene(scene, xRotate, yRotate);
        scene = Pipeline.scaleScene(scene);
        scene = Pipeline.translateScene(scene);

        Color[][] zBuffer = new Color[CANVAS_WIDTH][CANVAS_HEIGHT];
        float[][] zDepth = new float[CANVAS_WIDTH][CANVAS_HEIGHT];

        EdgeList edgeList;

        for (int x = 0; x < CANVAS_WIDTH; x++) { // initialise the zBuffer and Depth to white and infinity
            for (int y = 0; y < CANVAS_HEIGHT; y++) {
                zBuffer[x][y] = Color.white;
                zDepth[x][y] = Float.POSITIVE_INFINITY;
            }
        }

        for (Scene.Polygon p : scene.getPolygons()) { // go through all the polygons and compute the zBuffer
            if (!Pipeline.isHidden(p)) { // polygon is visible
                Color color = Pipeline.getShading(p, randomLightVectors, randomLightColours, scene.getLight(), p.getReflectance(), new Color(getAmbientLight()[0], getAmbientLight()[1], getAmbientLight()[2]));
                edgeList = Pipeline.computeEdgeList(p);
                Pipeline.computeZBuffer(zBuffer, zDepth, edgeList, color);
            }
        }

        //set the rotation amounts back to 0
        xRotate = 0f;
        yRotate = 0f;

        return convertBitmapToImage(zBuffer);
        /*
         * This method should put together the pieces of your renderer, as
         * described in the lecture. This will involve calling each of the
         * static method stubs in the Pipeline class, which you also need to
         * fill in.
         */
    }

    /**
     * Creates a new random light source and adds it to the list of colours and vectors
     */
    @Override
    protected void addNewLightSource() {
        // Makes a new random colour between 0-200 (not 255 as this can be too bright for the objects)
        randomLightColours.add(new Color(
                (int) (Math.random() * 200),
                (int) (Math.random() * 200),
                (int) (Math.random() * 200)));
        // Makes the point at which it is located random
        randomLightVectors.add(new Vector3D(
                (float) (Math.random() - Math.random()),
                (float) (Math.random() - Math.random()),
                (float) (Math.random() - Math.random())));
    }

    /**
     * Removes the last light source added
     */
    @Override
    protected void removeLightSource() {
        if (randomLightColours.size() > 0) {
            randomLightColours.remove(randomLightColours.size() - 1);
            randomLightVectors.remove(randomLightVectors.size() - 1);
        }
    }

    /**
     * Converts a 2D array of Colors to a BufferedImage. Assumes that bitmap is
     * indexed by column then row and has imageHeight rows and imageWidth
     * columns. Note that image.setRGB requires x (col) and y (row) are given in
     * that order.
     */
    private BufferedImage convertBitmapToImage(Color[][] bitmap) {
        BufferedImage image = new BufferedImage(CANVAS_WIDTH, CANVAS_HEIGHT, BufferedImage.TYPE_INT_RGB);
        for (int x = 0; x < CANVAS_WIDTH; x++) {
            for (int y = 0; y < CANVAS_HEIGHT; y++) {
                image.setRGB(x, y, bitmap[x][y].getRGB());
            }
        }
        return image;
    }

    public static void main(String[] args) {
        new Renderer();
    }
}

// code for comp261 assignments
