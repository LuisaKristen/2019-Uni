package renderer;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import renderer.Scene.Polygon;

/**
 * The Pipeline class has method stubs for all the major components of the
 * rendering pipeline, for you to fill in.
 * <p>
 * Some of these methods can get quite long, in which case you should strongly
 * consider moving them out into their own file. You'll need to update the
 * imports in the test suite if you do.
 */
public class Pipeline {



    /**
     * Returns true if the given polygon is facing away from the camera (and so
     * should be hidden), and false otherwise.
     */
    public static boolean isHidden(Polygon poly) {
        return getNormal(poly).z > 0;
    }

    /**
     * Computes the colour of a polygon on the screen, once the lights, their
     * angles relative to the polygon's face, and the reflectance of the polygon
     * have been accounted for.
     *
     * @param lightDirection The Vector3D pointing to the directional light read in from
     *                       the file.
     * @param lightColor     The color of that directional light.
     * @param ambientLight   The ambient light in the scene, i.e. light that doesn't depend
     *                       on the direction.
     */
    public static Color getShading(Polygon poly, ArrayList<Vector3D> lightSources, ArrayList<Color> lightColours, Vector3D lightDirection, Color lightColor, Color ambientLight) {

        Color reflectance = poly.getReflectance();
        int red;
        int green;
        int blue;

        Vector3D vectorNormal = getNormal(poly);
        float theta = vectorNormal.cosTheta(lightDirection); // technically cos theta
        if (theta < 0) // if cos(theta) is < 0, it should mulitply by 0 instead
            theta = 0;

        //calculates the base colour for without any extra lights per the lecture slides
         red = (int) (ambientLight.getRed()*(reflectance.getRed()/255.0f) + lightColor.getRed()*(reflectance.getRed()/255.0f)*theta);
         green = (int) (ambientLight.getGreen()*(reflectance.getGreen()/255.0f) + (lightColor.getGreen()*reflectance.getGreen()/255.0f)*theta);
         blue = (int) (ambientLight.getBlue()*(reflectance.getBlue()/255.0f) + (lightColor.getBlue()*reflectance.getBlue()/255.0f)*theta);

         // adds each of the random light sources
         for (int i=0; i<lightSources.size();i++) {
             float thetaLightSource = vectorNormal.cosTheta(lightSources.get(i));
             if (thetaLightSource>0){
                 red+=lightColours.get(i).getRed()*thetaLightSource;
                 green+=lightColours.get(i).getGreen()*thetaLightSource;
                 blue+=lightColours.get(i).getBlue()*thetaLightSource;
             }
         }

         // the Colour has to be between 0-255, so if they are outside this, they get set as the min or max
        red = Math.max(red , 0);
        green = Math.max(green , 0);
        blue = Math.max(blue, 0);

        red = Math.min(red, 255);
        green = Math.min(green, 255);
        blue = Math.min(blue, 255);

        return new Color(red, green, blue);
    }


    /**
     * This method should rotate the polygons and light such that the viewer is
     * looking down the Z-axis. The idea is that it returns an entirely new
     * Scene object, filled with new Polygons, that have been rotated.
     *
     * @param scene The original Scene.
     * @param xRot  An angle describing the viewer's rotation in the YZ-plane (i.e
     *              around the X-axis).
     * @param yRot  An angle describing the viewer's rotation in the XZ-plane (i.e
     *              around the Y-axis).
     * @return A new Scene where all the polygons and the light source have been
     * rotated accordingly.
     */
    public static Scene rotateScene(Scene scene, float xRot, float yRot) {
        if (scene==null)
            return null;

        //makes a new rotation out of two seperate x and y rotation transformations
        Transform rotateX = Transform.newXRotation(xRot);
        Transform rotateY = Transform.newYRotation(yRot);
        Transform rotation = rotateY.compose(rotateX);

        ArrayList <Polygon> newPolys=new ArrayList<>();
        Vector3D light,a,b,c;

        //rotates only the primary light source
        light=rotation.multiply(scene.getLight());

        //rotates each vertex of each polygon, makes a new polygon which is added to the list
        for (Polygon p : scene.getPolygons()){
            a=rotation.multiply(p.getVertices()[0]);
            b=rotation.multiply(p.getVertices()[1]);
            c=rotation.multiply(p.getVertices()[2]);

            newPolys.add(new Polygon(a,b,c,p.getReflectance()));
        }

        return new Scene (newPolys,light);
    }


    /**
     * This should translate the scene by the appropriate amount.
     *
     * @param scene
     * @return
     */
    public static Scene translateScene(Scene scene) {
        if (scene==null)
            return null;

        // creates a bounding box for the scene's polygons
        Rectangle boundingBox=makeBoundingBox(scene.getPolygons());

        // calculates the amount of translation required to move the object to the centre of the screen
        float deltaX =(float)( -boundingBox.x+(GUI.CANVAS_WIDTH/2)-(boundingBox.getMaxX()-boundingBox.getMinX())/2);
        float deltaY =(float) (-boundingBox.y+(GUI.CANVAS_HEIGHT/2)-(boundingBox.getMaxY()-boundingBox.getMinY())/2);

        Transform transformation = Transform.newTranslation(new Vector3D(deltaX,deltaY,0));

        // translates each vertex of each polygon
        for (Polygon p : scene.getPolygons()){
            for (int i=0; i<p.getVertices().length; i++){
                p.getVertices()[i]= transformation.multiply(p.getVertices()[i]);
            }
        }

        return new Scene(scene.getPolygons(),scene.getLight());
    }


    /**
     * This should scale the scene.
     *
     * @param scene
     * @return
     */
    public static Scene scaleScene(Scene scene) {
        if (scene==null)
            return null;

        Rectangle boundingBox=makeBoundingBox(scene.getPolygons());

        float width = (float) (boundingBox.width);
        float height = (float) (boundingBox.height);

        float scale=1.0f;


        // if its saller than the screen, make it 1/4 the size
        if(height<GUI.CANVAS_HEIGHT/4&& (width - GUI.CANVAS_WIDTH < height - GUI.CANVAS_HEIGHT)){
            scale= ((GUI.CANVAS_HEIGHT-1)/4) * height;
        }
        else if (width<GUI.CANVAS_WIDTH/4 && (width - GUI.CANVAS_WIDTH >= height - GUI.CANVAS_HEIGHT)){
            scale = ((GUI.CANVAS_WIDTH-1)/4) * width;
        }


        // if its bigger than the screen, make it 1/4 size
        if (width>GUI.CANVAS_WIDTH && (width - GUI.CANVAS_WIDTH > height - GUI.CANVAS_HEIGHT)){
            scale = ((GUI.CANVAS_WIDTH-1)/4) / width;
        }
        else if(height>GUI.CANVAS_HEIGHT && (width - GUI.CANVAS_WIDTH < height - GUI.CANVAS_HEIGHT)){
            scale= ((GUI.CANVAS_HEIGHT-1)/4) / height;
        }


        if (scale==1.0f){ //if the scale is 1, it doesn't need to be scaled, so we can just return the current scene
            return scene;
        }

        //scale by the same amount in all three axes
        Transform transformation = Transform.newScale(scale,scale,scale);

        //scale each vertex of each polygon
        for (Polygon p : scene.getPolygons()){
            for (int i=0; i<p.getVertices().length; i++){
                p.getVertices()[i]= transformation.multiply(p.getVertices()[i]);
            }
        }

        Scene newScene=new Scene (scene.getPolygons(),scene.getLight());

        //check if the new width or height happen to be greater than the screen, and re-scale
         boundingBox=makeBoundingBox(newScene.getPolygons());
         width = (float) (boundingBox.width);
         height = (float) (boundingBox.height);
         if (width>GUI.CANVAS_WIDTH ||height>GUI.CANVAS_HEIGHT )
            newScene= scaleScene(newScene);


        return newScene;
    }

    /**
     * Make a bounding box from a given set of polygons
     *
     * For each polygon, check the x and y and store the biggest and smallest value.
     * This gives us the outmost corners of the scene
     * A new rectangle with these points is returned
     * @param polys
     * @return
     */
    private static Rectangle makeBoundingBox(List<Scene.Polygon> polys ){
        float minY = Float.POSITIVE_INFINITY;
        float minX = Float.POSITIVE_INFINITY;

        float maxY = Float.NEGATIVE_INFINITY;
        float maxX = Float.NEGATIVE_INFINITY;


        for (Polygon p : polys){
            Vector3D [] vectors = p.getVertices();
            for (Vector3D v : vectors){
                minY=Math.min(v.y, minY);
                maxY=Math.max(v.y, maxY);
                minX=Math.min(v.x,minX);
                maxX=Math.max(v.x,maxX);
            }
        }

        return new Rectangle(Math.round(minX),
                Math.round(minY),
                Math.round(maxX-minX),
                Math.round(maxY-minY));



    }



    /**
     * Computes the edgelist of a single provided polygon, as per the lecture
     * slides.
     */
    public static EdgeList computeEdgeList(Polygon poly) {
        Vector3D[] vectors = Arrays.copyOf(poly.getVertices(), 3);

        int minY = Integer.MAX_VALUE;
        int maxY = Integer.MIN_VALUE;

        //finds the min and max y value of the polygon
        for (Vector3D v : vectors) {
            if (v.y > maxY) {
                maxY = Math.round(v.y);
            }
            if (v.y < minY) {
                minY = Math.round(v.y);
            }
        }

        EdgeList edgeList = new EdgeList(minY, maxY);

        Vector3D a;
        Vector3D b;

        // creates the edge list per the lecture slides
        for (int i = 0; i < 3; i++) {
            a = vectors[i];
            b = vectors[(i + 1) % 3]; // next one, or the first one on the last one

            float slopeX = (b.x - a.x) /(b.y - a.y);
            float slopeZ = (b.z - a.z) / (b.y - a.y);

            float x = a.x;
            int y = Math.round(a.y);
            float z = a.z;

            if (a.y < b.y) {
                while (y <= Math.round(b.y)) {
                    edgeList.setLeftX(y, x);
                    edgeList.setLeftZ(y, z);
                    x += slopeX;
                    z += slopeZ;
                    y++;
                }
            } else {
                while (y >= Math.round(b.y)) {
                    edgeList.setRightX(y, x);
                    edgeList.setRightZ(y, z);
                    x -= slopeX;
                    z -= slopeZ;
                    y--;
                }
            }
        }
        return edgeList;
    }

    /**
     * Fills a zbuffer with the contents of a single edge list according to the
     * lecture slides.
     * <p>
     * The idea here is to make zbuffer and zdepth arrays in your main loop, and
     * pass them into the method to be modified.
     *
     * @param zbuffer      A double array of colours representing the Color at each pixel
     *                     so far.
     * @param zdepth       A double array of floats storing the z-value of each pixel
     *                     that has been coloured in so far.
     * @param polyEdgeList The edgelist of the polygon to add into the zbuffer.
     * @param polyColor    The colour of the polygon to add into the zbuffer.
     */
    public static void computeZBuffer(Color[][] zbuffer, float[][] zdepth, EdgeList polyEdgeList, Color polyColor) {
        for (int y = polyEdgeList.getStartY(); y < polyEdgeList.getEndY(); y++) {
            float slope = (polyEdgeList.getRightZ(y) - polyEdgeList.getLeftZ(y)) / (polyEdgeList.getRightX(y) - polyEdgeList.getLeftX(y));
            int x = Math.round(polyEdgeList.getLeftX(y));
            int z = Math.round(polyEdgeList.getLeftZ(y) + slope * (x - polyEdgeList.getLeftX(y)));

            while (x <= Math.round(polyEdgeList.getRightX(y))) {
                if (x<zdepth.length &&x >=0 && y<zdepth[0].length && y>=0) { // check its within bounds
                    if (z < zdepth[x][y]) {
                        zbuffer[x][y] = polyColor;
                        zdepth[x][y] = z;
                    }
                }
                z += slope;
                x++;
            }
        }
    }

    /**
     * Returns the normal-vector of a given polygon per the lecture slides
     * @param poly
     * @return
     */
    private static Vector3D getNormal(Polygon poly) {
        Vector3D[] points = poly.getVertices();
        Vector3D a = points[1].minus(points[0]);
        Vector3D b = points[2].minus(points[1]);
        Vector3D normal = a.crossProduct(b);
        return normal;
    }


}

// code for comp261 assignments
